import tkinter as tk

# initiallize app
root = tk.Tk()

# run app
root.mainloop()